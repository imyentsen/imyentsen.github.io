<?php

function virtual_conference_google_fonts()
{
    $fonts = array(
        'Abel'       => 'Abel',
        'Montserrat' => 'Montserrat',
        'Poppins'    => 'Poppins',
        'Raleway'    => 'Raleway',
        'Roboto'     => 'Roboto',
    );
    return $fonts;
}
