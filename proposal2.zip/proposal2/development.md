# Prefix Placeholders

Starter theme prefix placeholders were replaced with these values:

| Placeholder  | Replacement  |
|--------------|--------------|
| `Themename`  | Michelle     |
| `theme-slug` | michelle     |
| `theme_slug` | michelle     |
| `THEME_SLUG` | MICHELLE     |
| `Theme_Slug` | Michelle     |
| `themeSlug`  | michelle     |
| `__1.0.0`    | 1.0.0        |
